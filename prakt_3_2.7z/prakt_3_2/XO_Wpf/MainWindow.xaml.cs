﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static XO_Wpf.XOField;

namespace XO_Wpf
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow :Window
    {
        private readonly double rectWidth;
        private readonly double rectHeight;
        private readonly XOField XOGame = new XOField( );
        public MainWindow ()
        {
            InitializeComponent( );
            rectWidth = gameField.Width / 3;
            rectHeight = gameField.Height / 3;
            NewGame();
            XOGame.OnTurn += (row, col, elem) =>
            {
                char symbol = elem == XOElement.Cross ? 'X' : 'O';
                printSymbol(row, col, symbol);
                if (gameField.Children.Count == 18 && XOGame.Winner == XOElement.None)
                {
                    MessageBox.Show("Победила дружба:)", "GAME OVER!!!");
                }

            };
            XOGame.OnGameOver += (winner) =>
            {
                if (winner == XOElement.Cross)
                {
                    MessageBox.Show("'Х' Победил", "GAME OVER!!!");
                }
                else if (winner == XOElement.Circle)
                {
                    MessageBox.Show("'O' Победил", "GAME OVER!!!");
                }

            };
        }
        private (int, int) calcCell (double x, double y)
        {
            int row = (int) (y / rectHeight);
            int col = (int) (x / rectWidth);
            return (row, col);
        }
        private void printSymbol (int row, int col, char symbol)
        {

            (double cornerX, double cornerY) = (rectHeight * col, rectWidth * row);

            Label text = new Label( );
            text.Content = symbol;
            text.FontSize = rectWidth / 1.5;

            Canvas.SetLeft(text, cornerX + rectWidth / 4);
            Canvas.SetTop(text, cornerY);
            gameField.Children.Add(text);
        }
        private void makeTurn (object sender, MouseButtonEventArgs e)
        {
            (int row, int col) = calcCell(e.GetPosition(gameField).X, e.GetPosition(gameField).Y);
            XOGame.TryTurn(row, col);
        }

        public void NewGame() 
        {
            XOGame.Clear();
            gameField.Children.Clear();
            double y = 0;
            for (int i = 1; i <= 3; i++)
            {
                double x = 0;
                for (int j = 1; j <= 3; j++)
                {
                    var rect = new Rectangle();
                    rect.Stroke = Brushes.Black;
                    rect.StrokeThickness = 1;
                    rect.Height = rectHeight;
                    rect.Width = rectWidth;
                    Canvas.SetLeft(rect, x);
                    Canvas.SetTop(rect, y);
                    gameField.Children.Add(rect);
                    x += rectWidth;
                }
                y += rectHeight;

            }
        }
        private void NewGame_Click(object sender, RoutedEventArgs e)
        {
            NewGame();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
